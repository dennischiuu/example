//
//  ViewController.swift
//  Lab3
//
//  Created by stit on 27/9/2018.
//  Copyright © 2018 ABC. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    let inputs = ["hi" ," hello", "bonjour"]

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var theSwitch: UISwitch!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var picker: UIPickerView!
    
    @IBAction func sliderAction(_ sender: Any) {
        self.label.text = "\(self.slider.value)"
    }
    
    
    @IBAction func switchAction(_ sender: Any) {
        self.label.text = "\(self.theSwitch.isOn)"
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return inputs.count
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return inputs[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.label.text = "\(inputs[row])"
    }
    
    @IBAction func btnClicked(_ sender: Any) {
        self.label.text = "animation start"
        let alpha = self.theSwitch.alpha < 2.0 ? CGFloat(1.0) : CGFloat(0.1)
        
        UIView.animate(withDuration: 2.0, animations: {
            self.theSwitch.alpha = alpha
        }, completion:{
            (completed) in
            self.label.text = "animation ended"
        })
    }
    @objc func keyboardWillShow(_ notification : NSNotification){
        self.label.text = "kb shown"
    }
    
    @objc func keyboardWillHide(_ notification : NSNotification){
        self.label.text = "kn hide"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("view did load")
        if let appdelegate = UIApplication.shared.delegate as? AppDelegate{
            print("the number : \(appdelegate.numberInAppDelegate)")
        }
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("view will appear")
        
        NotificationCenter.default.addObserver(self, selector:#selector(ViewController.keyboardWillShow(_:)) , name: .UIKeyboardDidShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector:#selector(ViewController.keyboardWillHide(_:)) , name: .UIKeyboardDidHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("view will disappear")
        
        NotificationCenter.default.removeObserver(self,name: .UIKeyboardDidShow, object: nil)
        
        NotificationCenter.default.removeObserver(self,name: .UIKeyboardDidHide, object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

