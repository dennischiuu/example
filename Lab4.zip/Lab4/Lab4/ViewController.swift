//
//  ViewController.swift
//  Lab4
//
//  Created by itadmin on 4/10/2018.
//  Copyright © 2018 itadmin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var noteManager = NoteManager()
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var textField: UITextField!
    
    func showNoteOnTextView(){
        var text = ""
        for i in 0..<noteManager.count() {
            let note = noteManager.note(at: i)
            if i == 0 {
                text = "\(note.text)"
            }else{
                text = "\(text)\n\(note.text)"
            }
        }
        self.textView.text = text;
        
    }
    
    @IBAction func addBtnClick(_ sender: Any) {
        if let text = textField.text{
            if text.characters.count > 0{
                let note = Note(text: text)
                self.noteManager.appendNote(expense: note)
                self.label.text = "\"\(note.text)\" added"
                self.showNoteOnTextView()
                self.textField.text = " "
            }else{
                self.label.text = "textfield is empty"
            }
        }
    }
    
    @IBAction func delectBtnClick(_ sender: Any) {
        if let note = self.noteManager.removeNote(){
            self.label.text = "\"\(note.text)\" removed"
            self.showNoteOnTextView()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.textView.text = ""
        self.showNoteOnTextView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        if segue.identifier == "showRandomSegue"{
            if let destination = segue.destination as? RandomResultViewController{
                if self.noteManager.count() > 0 {
                    let randomNo = Int(arc4random()) % self.noteManager.count()
                    let note = self.noteManager.note(at: randomNo)
                    destination.randomResult = note.text
                }
            }
        }
    }
    
    @IBAction func exitFromModalAdd(segue: UIStoryboardSegue) {
        // Get the new view controller using segue.destinationViewController.
        if segue.identifier == "backFromModalAddSegue"{
            if let source = segue.source as? AddNoteViewController{
                if source.textField.text!.characters.count > 0{
                    let note = Note(text: source.textField.text!)
                    self.noteManager.appendNote(expense: note)
                    self.label.text = "\"\(note.text)\" added"
                    self.showNoteOnTextView()
                }
            }
        }
        // Pass the selected object to the new view controller.
    }
    
    
}

