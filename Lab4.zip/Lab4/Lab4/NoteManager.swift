//
//  NoteManager.swift
//  Lab4
//
//  Created by itadmin on 4/10/2018.
//  Copyright © 2018 itadmin. All rights reserved.
//

import UIKit

class Note : NSObject{
    var text : String
    
    init(text : String){
        self.text = text;
    }
}
class NoteManager: NSObject {
        private var notes = [Note]()
    
    func appendNote(expense : Note){
        notes.append(expense)
    }
    
    func removeNote() -> Note?{
        if notes.count < 1{
        return nil;
        }
        return notes.removeLast()
    }
    

    func count() -> Int {
        return notes.count
    }
    
    func note(at index : Int) -> Note{
        return notes[index]
    }
}
